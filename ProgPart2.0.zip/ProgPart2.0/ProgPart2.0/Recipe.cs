﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgPart2._0
{
    internal class Recipe
    {
        public string Name { get; set; }
        public List<Ingredients> Ingredients { get; set; }
        public List<string> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredients>();
            Steps = new List<string>();
        }

        public void EnterDetails()
        {
            Console.Write("Enter the name of the recipe: ");
            Name = Console.ReadLine();

            int numIngredients;
            Console.Write("\nEnter the number of ingredients: ");
            while (!int.TryParse(Console.ReadLine(), out numIngredients) || numIngredients <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
                Console.Write("Enter the number of ingredients: ");
            }

            for (int i = 0; i < numIngredients; i++)
            {
                Console.Write($"Enter the name of ingredient {i + 1}: ");
                string name = Console.ReadLine();

                double quantity;
                Console.Write($"Enter the quantity of {name}: ");
                while (!double.TryParse(Console.ReadLine(), out quantity) || quantity <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive number.");
                    Console.Write($"Enter the quantity of {name}: ");
                }

                Console.Write($"Enter the unit of measurement for {name}: ");
                string unit = Console.ReadLine();

                Console.Write($"Enter the number of calories for {name}: ");
                double calories;
                while (!double.TryParse(Console.ReadLine(), out calories) || calories <= 0)
                {
                    Console.WriteLine("Invalid input. Please enter a positive number.");
                    Console.Write($"Enter the number of calories for {name}: ");
                }

                Console.Write($"Enter the food group for {name}: ");
                string foodGroup = Console.ReadLine();

                Ingredients.Add(new Ingredients { Name = name, Quantity = quantity, OriginalQuantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
            }

            int numSteps;
            Console.Write("\nEnter the number of steps: ");
            while (!int.TryParse(Console.ReadLine(), out numSteps) || numSteps <= 0)
            {
                Console.WriteLine("Invalid input. Please enter a positive integer.");
                Console.Write("Enter the number of steps: ");
            }

            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                Steps.Add(Console.ReadLine());
            }

            Console.WriteLine("Recipe details entered successfully!");

            double totalCalories = CalculateTotalCalories();
            if (totalCalories > 300)
            {
                Console.WriteLine($"Warning: Total calories of the recipe '{Name}' exceed 300!");
            }
        }

        public void Display()
        {
            Console.WriteLine($"\nRecipe: {Name}");

            if (Ingredients.Count == 0)
            {
                Console.WriteLine("No ingredients entered.");
            }
            else
            {
                Console.WriteLine("\nIngredients:");
                foreach (var ingredient in Ingredients)
                {
                    Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
                }
            }

            if (Steps.Count == 0)
            {
                Console.WriteLine("No steps entered.");
            }
            else
            {
                Console.WriteLine("\nSteps:");
                for (int i = 0; i < Steps.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {Steps[i]}");
                }
            }
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }

            Console.WriteLine("Recipe scaled successfully!");
        }

        public void ResetQuantities()
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity = ingredient.OriginalQuantity;
            }

            Console.WriteLine("Quantities reset successfully!");
        }

        public void ClearData()
        {
            Ingredients.Clear();
            Steps.Clear();
            Console.WriteLine("Recipe data cleared successfully!");
        }

        public double CalculateTotalCalories()
        {
            double totalCalories = 0;
            foreach (var ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories * ingredient.Quantity;
            }
            return totalCalories;
        }
    }

}

