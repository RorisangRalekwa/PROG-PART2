﻿using ProgPart2._0;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Recipe Application !\n");
        Console.WriteLine("============================");

        var recipes = new List<Recipe>();
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("\nMenu:");
            Console.WriteLine("1. Enter recipe details");
            Console.WriteLine("2. Display all recipes");
            Console.WriteLine("3. Display recipe by name");
            Console.WriteLine("4. Scale recipe");
            Console.WriteLine("5. Reset quantities");
            Console.WriteLine("6. Clear all data");
            Console.WriteLine("7. Exit");
            Console.WriteLine("===============================")
            Console.Write("Enter your choice: ");

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid choice. Please try again.");
                continue;
            }

            switch (choice)
            {
                case 1:
                    var recipe = new Recipe();
                    recipe.EnterDetails();
                    recipes.Add(recipe);
                    break;
                case 2:
                    Console.WriteLine("Recipes:");
                    foreach (var r in recipes)
                    {
                        Console.WriteLine(r.Name);
                    }
                    break;
                case 3:
                    Console.Write("Enter the name of the recipe to display: ");
                    string recipeName = Console.ReadLine();
                    var selectedRecipe = recipes.Find(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
                    if (selectedRecipe != null)
                    {
                        selectedRecipe.Display();
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 4:
                    Console.Write("Enter the name of the recipe to scale: ");
                    string recipeToScale = Console.ReadLine();
                    var recipeToScaleObj = recipes.Find(r => r.Name.Equals(recipeToScale, StringComparison.OrdinalIgnoreCase));
                    if (recipeToScaleObj != null)
                    {
                        Console.Write("Enter scale factor (0.5, 2, or 3): ");
                        double scaleFactor;
                        if (double.TryParse(Console.ReadLine(), out scaleFactor) &&
                            (scaleFactor == 0.5 || scaleFactor == 2 || scaleFactor == 3))
                        {
                            recipeToScaleObj.Scale(scaleFactor);
                        }
                        else
                        {
                            Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 5:
                    Console.Write("Enter the name of the recipe to reset quantities: ");
                    string recipeToReset = Console.ReadLine();
                    var recipeToResetObj = recipes.Find(r => r.Name.Equals(recipeToReset, StringComparison.OrdinalIgnoreCase));
                    if (recipeToResetObj != null)
                    {
                        recipeToResetObj.ResetQuantities();
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 6:
                    Console.Write("Enter the name of the recipe to clear data: ");
                    string recipeToClear = Console.ReadLine();
                    var recipeToClearObj = recipes.Find(r => r.Name.Equals(recipeToClear, StringComparison.OrdinalIgnoreCase));
                    if (recipeToClearObj != null)
                    {
                        recipeToClearObj.ClearData();
                        recipes.Remove(recipeToClearObj); // Remove the cleared recipe from the list
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }

        Console.WriteLine("\nThank you for using the Recipe App!");
    }
}
